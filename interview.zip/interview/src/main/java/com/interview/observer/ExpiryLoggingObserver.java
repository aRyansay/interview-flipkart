package com.interview.observer;

import com.interview.entity.User;

public class ExpiryLoggingObserver implements ExpiryObserver {
    @Override
    public void onCoinExpiry(User user, int expiredCoins, int day) {
        System.out.println("[EXPIRY NOTIFICATION] User " + user.getUserId() + 
                          " lost " + expiredCoins + " SuperCoins on day " + day);
    }
}
