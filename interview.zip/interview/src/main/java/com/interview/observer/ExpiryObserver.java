package com.interview.observer;

import com.interview.entity.User;

public interface ExpiryObserver {
    void onCoinExpiry(User user, int expiredCoins, int day);
}
