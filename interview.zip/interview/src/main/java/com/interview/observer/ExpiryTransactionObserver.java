package com.interview.observer;

import com.interview.Enum.TransactionStatus;
import com.interview.Enum.TransactionType;
import com.interview.entity.Transaction;
import com.interview.entity.User;

import java.util.UUID;

public class ExpiryTransactionObserver implements ExpiryObserver {
    @Override
    public void onCoinExpiry(User user, int expiredCoins, int day) {
        String systemOrderId = "EXPIRY_" + day;
        Transaction txn = new Transaction(
                UUID.randomUUID().toString(),
                TransactionType.EXPIRY,
                expiredCoins,
                day,
                systemOrderId
        );
        txn.setStatus(TransactionStatus.COMPLETED);
        user.addTransaction(txn);
    }
}
