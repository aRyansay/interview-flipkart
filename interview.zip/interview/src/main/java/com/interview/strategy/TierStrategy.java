package com.interview.strategy;

public interface TierStrategy {
    int calculateCoins(int amount);
}
