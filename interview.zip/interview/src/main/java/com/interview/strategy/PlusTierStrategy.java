package com.interview.strategy;

public class PlusTierStrategy implements TierStrategy {
    @Override
    public int calculateCoins(int amount) {
        return Math.min((amount / 100) * 4, 100);
    }
}