package com.interview.strategy;

public class RegularTierStrategy implements TierStrategy {
    @Override
    public int calculateCoins(int amount) {
        return Math.min((amount / 100) * 2, 50);
    }
}