package com.interview.entity;

import com.interview.Enum.TransactionStatus;
import com.interview.Enum.TransactionType;
import java.util.*;

public class Transaction {
    private String txnId;
    private TransactionType type;
    private TransactionStatus status;
    private int coins;
    private int day;
    private String orderId;
    private List<CoinBatch> expiredBatches = new ArrayList<>();
    private Map<CoinBatch, Integer> batchBreakup = new HashMap<>();

    public Transaction(String txnId, TransactionType type, int coins, int day, String orderId) {
        this.txnId = txnId;
        this.type = type;
        this.coins = coins;
        this.day = day;
        this.orderId = orderId;
        this.status = TransactionStatus.PENDING;
    }

    // Getters
    public String getTxnId() { return txnId; }
    public TransactionType getType() { return type; }
    public TransactionStatus getStatus() { return status; }
    public int getCoins() { return coins; }
    public int getDay() { return day; }
    public String getOrderId() { return orderId; }
    public List<CoinBatch> getExpiredBatches() { return expiredBatches; }
    public Map<CoinBatch, Integer> getBatchBreakup() { return batchBreakup; }

    // Setters
    public void setStatus(TransactionStatus status) { this.status = status; }
    public void setBatchBreakup(Map<CoinBatch, Integer> breakup) { this.batchBreakup = breakup; }
    public void addExpiredBatch(CoinBatch batch) { this.expiredBatches.add(batch); }

    @Override
    public String toString() {
        return "TxnId: " + txnId + ", Type: " + type + ", Amount: " + coins + ", Day: " + day + 
               ", Status: " + status + ", OrderId: " + orderId;
    }
}
