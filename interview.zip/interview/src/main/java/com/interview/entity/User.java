package com.interview.entity;

import com.interview.Enum.Tier;
import java.util.*;

public class User {
    private String userId;
    private Tier tier;
    private Wallet wallet;
    private List<Transaction> transactions = new ArrayList<>();
    private int lifetimeCoins = 0;

    public User(String userId, Tier tier) {
        this.userId = userId;
        this.tier = tier;
        this.wallet = new Wallet();
    }

    // Getters
    public String getUserId() { return userId; }
    public Tier getTier() { return tier; }
    public Wallet getWallet() { return wallet; }
    public List<Transaction> getTransactions() { return transactions; }
    public int getLifetimeCoins() { return lifetimeCoins; }

    // Setters
    public void setTier(Tier tier) { this.tier = tier; }
    public void setLifetimeCoins(int coins) { this.lifetimeCoins = coins; }

    // Business Methods
    public void addTransaction(Transaction txn) {
        this.transactions.add(txn);
    }

    public void incrementLifetimeCoins(int coins) {
        this.lifetimeCoins += coins;
    }

    @Override
    public String toString() {
        return userId;
    }
}