package com.interview.entity;

public class CoinBatch {
    public int coins;
    public int expiryDay;

    public CoinBatch(int coins, int expiryDay) {
        this.coins = coins;
        this.expiryDay = expiryDay;
    }
}