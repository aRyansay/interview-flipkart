package com.interview.entity;

import com.interview.exception.InsufficientBalanceException;
import java.util.*;

public class Wallet {
    Queue<CoinBatch> batches = new LinkedList<>();

    public void credit(int coins, int currentDay) {
        batches.add(new CoinBatch(coins, currentDay + 30));
    }

    public int getBalance(int currentDay) {
        expireCoins(currentDay);
        int sum = 0;
        for (CoinBatch b : batches) sum += b.coins;
        return sum;
    }

    public int expireCoins(int currentDay) {
        int expiredCoins = 0;
        while (!batches.isEmpty() && batches.peek().expiryDay <= currentDay) {
            expiredCoins += batches.poll().coins;
        }
        return expiredCoins;
    }

    public Map<CoinBatch, Integer> debit(int coins, int currentDay) {
        expireCoins(currentDay);

        int available = getBalance(currentDay);
        if (available < coins) throw new InsufficientBalanceException();

        Map<CoinBatch, Integer> used = new HashMap<>();

        while (coins > 0) {
            CoinBatch batch = batches.peek();
            int take = Math.min(batch.coins, coins);

            used.put(batch, take);

            batch.coins -= take;
            coins -= take;

            if (batch.coins == 0) batches.poll();
        }
        return used;
    }

    public void restore(Map<CoinBatch, Integer> used) {
        for (Map.Entry<CoinBatch, Integer> e : used.entrySet()) {
            e.getKey().coins += e.getValue();
        }
    }
}