package com.interview.exception;


public class InsufficientBalanceException extends RuntimeException {
    public InsufficientBalanceException() {
        super("Insufficient SuperCoins");
    }
}