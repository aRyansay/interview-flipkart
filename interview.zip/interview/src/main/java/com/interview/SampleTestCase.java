package com.interview;

import com.interview.Enum.Tier;
import com.interview.context.SystemContext;
import com.interview.entity.User;
import com.interview.observer.ExpiryLoggingObserver;
import com.interview.observer.ExpiryTransactionObserver;
import com.interview.service.UserService;
import com.interview.service.WalletService;
import java.util.*;

/**
 * Sample Test Case: User-provided test parameters
 * Comprehensive verification of all features with specific assertions
 * 
 * Test Scenario:
 * - preloadUsers: u1 (REGULAR), u2 (PLUS)
 * - Day 1-36 operations with specific assertions
 */
public class SampleTestCase {

    private static UserService userService = new UserService();
    private static WalletService walletService = new WalletService();
    private static SystemContext ctx = SystemContext.getInstance();
    private static Map<String, User> users = new HashMap<>();

    public static void main(String[] args) {
        System.out.println("╔═══════════════════════════════════════════════════════════════════╗");
        System.out.println("║         SAMPLE TEST CASE - COMPREHENSIVE WORKFLOW                 ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════════╝\n");

        try {
            // Register observers for expiry events
            walletService.registerExpiryObserver(new ExpiryTransactionObserver());
            walletService.registerExpiryObserver(new ExpiryLoggingObserver());
            
            preloadUsers();
            testScenario();
            System.out.println("\n✅ ALL TESTS PASSED\n");
        } catch (AssertionError e) {
            System.out.println("\n❌ TEST FAILED: " + e.getMessage() + "\n");
            System.exit(1);
        } catch (Exception e) {
            System.out.println("\n❌ UNEXPECTED ERROR: " + e.getMessage() + "\n");
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void preloadUsers() {
        System.out.println("┌─────────────────────────────────────────────────────┐");
        System.out.println("  SETUP: preloadUsers([u1: REGULAR, u2: PLUS])");
        System.out.println("└─────────────────────────────────────────────────────┘\n");

        User u1 = new User("u1", Tier.REGULAR);
        User u2 = new User("u2", Tier.PLUS);

        users.put("u1", u1);
        users.put("u2", u2);

        System.out.println("✓ User u1 created (REGULAR tier)");
        System.out.println("✓ User u2 created (PLUS tier)\n");
    }

//    private static void testScenario() {
//        // ==================== DAY 1 ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 1: setCurrentDay(1) + login(u1)");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        ctx.setCurrentDay(1);
//        userService.login(users.get("u1"));
//        System.out.println("✓ Current Day: 1");
//        System.out.println("✓ Logged in: u1\n");
//
//        // ==================== DAY 1: EARN 50 COINS ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 2: earnCoins(O-101, 3000)");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        walletService.earnCoins("O-101", 3000);
//        System.out.println("Expected: Earned 50 coins (3000/100 * 2 = 60, capped at 50)");
//        System.out.println("Expected Expiry: Day 31");
//        System.out.println("Expected Tier: REGULAR");
//        System.out.println("Expected Status: COMPLETED");
//
//        int balance1 = users.get("u1").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance after O-101", 50, balance1);
//        assertEquals("Lifetime coins", 50, users.get("u1").lifetimeCoins);
//        assertEquals("Tier", Tier.REGULAR, users.get("u1").tier);
//
//        System.out.println("✓ Earned: 50 coins");
//        System.out.println("✓ Balance: " + balance1);
//        System.out.println("✓ Lifetime Coins: " + users.get("u1").lifetimeCoins);
//        System.out.println("✓ Tier: " + users.get("u1").tier + "\n");
//
//        // ==================== DAY 10: EARN 50 MORE COINS ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 3: setCurrentDay(10) + earnCoins(O-102, 5000)");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        ctx.setCurrentDay(10);
//        walletService.earnCoins("O-102", 5000);
//        System.out.println("Expected: Earned 50 coins (5000/100 * 2 = 100, capped at 50)");
//        System.out.println("Expected Expiry: Day 40");
//
//        int balance2 = users.get("u1").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance after O-102", 100, balance2);
//        assertEquals("Lifetime coins", 100, users.get("u1").lifetimeCoins);
//
//        System.out.println("✓ Earned: 50 coins");
//        System.out.println("✓ Balance: " + balance2 + " (50 from day 1 + 50 from day 10)");
//        System.out.println("✓ Lifetime Coins: " + users.get("u1").lifetimeCoins + "\n");
//
//        // ==================== DAY 15: SPEND 30 COINS ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 4: setCurrentDay(15) + spendCoins(O-103, 30)");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        ctx.setCurrentDay(15);
//        walletService.spendCoins("O-103", 30);
//        System.out.println("Expected: Spend 30 coins (FIFO from day 1 batch)");
//        System.out.println("Expected Remaining from Day1 batch: 20 coins");
//
//        int balance3 = users.get("u1").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance after spending 30", 70, balance3);
//
//        System.out.println("✓ Spent: 30 coins");
//        System.out.println("✓ Balance: " + balance3 + " (20 from day 1 + 50 from day 10)\n");
//
//        // ==================== DAY 35: CHECK BALANCE ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 5: setCurrentDay(35) + checkBalance()");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        ctx.setCurrentDay(35);
//        System.out.println("Expected: 20 coins from day 1 expire (earned day 1, expires day 31)");
//        System.out.println("Expected: 50 coins from day 10 still valid (expires day 40)");
//        System.out.println("Expected Balance: 50 coins");
//
//        walletService.checkBalance();
//
//        int balance35 = users.get("u1").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance after expiry (day 1 batch expired)", 50, balance35);
//        assertEquals("Tier at day 35", Tier.REGULAR, users.get("u1").tier);
//
//        System.out.println("✓ Expired coins: 20 (from day 1)");
//        System.out.println("✓ Valid balance: " + balance35);
//        System.out.println("✓ Tier: " + users.get("u1").tier + "\n");
//
//        // ==================== DAY 35: ATTEMPT SPEND 100 (SHOULD FAIL) ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 6: spendCoins(O-104, 100) [SHOULD FAIL]");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        System.out.println("Expected: InsufficientBalanceException (50 available < 100 required)");
//        System.out.println("Expected Status: REJECTED");
//
//        try {
//            walletService.spendCoins("O-104", 100);
//            throw new AssertionError("Expected InsufficientBalanceException but operation succeeded");
//        } catch (com.interview.exception.InsufficientBalanceException e) {
//            System.out.println("✓ Exception thrown: " + e.getMessage());
//            System.out.println("✓ Transaction Status: REJECTED\n");
//        }
//
//        // ==================== DAY 35: SPEND 40 COINS ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 7: spendCoins(O-105, 40)");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        walletService.spendCoins("O-105", 40);
//        System.out.println("Expected: Spend 40 coins from day 10 batch");
//        System.out.println("Expected Remaining: 10 coins");
//
//        int balance35b = users.get("u1").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance after spending 40", 10, balance35b);
//
//        System.out.println("✓ Spent: 40 coins");
//        System.out.println("✓ Balance: " + balance35b + "\n");
//
//        // ==================== DAY 36: CANCEL ORDER ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 8: setCurrentDay(36) + cancelOrder(O-105)");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        ctx.setCurrentDay(36);
//        walletService.cancelOrder("O-105");
//        System.out.println("Expected: Refund 40 coins");
//        System.out.println("Expected Refund Expiry: Day 66 (36 + 30)");
//        System.out.println("Expected New Balance: 50 (10 remaining + 40 refunded)");
//
//        int balance36 = users.get("u1").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance after refund", 50, balance36);
//
//        System.out.println("✓ Refunded: 40 coins");
//        System.out.println("✓ Balance: " + balance36 + "\n");
//
//        // ==================== VIEW TRANSACTION HISTORY ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 9: viewTransactionHistory() - User u1");
//        System.out.println("└────────────────────────────────────────────────┘\n");
//
//        System.out.println("Expected Transactions:");
//        System.out.println("[Day 1]  CREDIT 50 (O-101) - COMPLETED");
//        System.out.println("[Day 10] CREDIT 50 (O-102) - COMPLETED");
//        System.out.println("[Day 15] DEBIT 30 (O-103) - COMPLETED");
//        System.out.println("[Day 35] EXPIRY 20 - COMPLETED");
//        System.out.println("[Day 35] DEBIT 100 (O-104) - REJECTED");
//        System.out.println("[Day 35] DEBIT 40 (O-105) - COMPLETED");
//        System.out.println("[Day 36] REFUND 40 (O-105) - COMPLETED\n");
//
//        System.out.println("Actual Transactions:\n");
//        walletService.history();
//
//        assertEquals("Transaction count", 7, users.get("u1").transactions.size());
//        System.out.println("✓ Total transactions: 7\n");
//
//        // ==================== LOGOUT & SWITCH TO USER 2 ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 10: logout() + login(u2)");
//        System.out.println("└────────────────────────────────────────────────┘\n");
//
//        userService.logout();
//        System.out.println("✓ User u1 logged out");
//
//        userService.login(users.get("u2"));
//        System.out.println("✓ User u2 logged in (PLUS tier)\n");
//
//        // ==================== DAY 36: USER 2 EARNS COINS ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 11: earnCoins(O-201, 2000) - PLUS Tier");
//        System.out.println("└────────────────────────────────────────────────┘");
//
//        ctx.setCurrentDay(36);
//        walletService.earnCoins("O-201", 2000);
//        System.out.println("Expected: Earned 80 coins (PLUS tier: 2000/100 * 4 = 80)");
//        System.out.println("Expected Expiry: Day 66 (36 + 30)");
//
//        int balance_u2 = users.get("u2").wallet.getBalance(ctx.currentDay);
//        assertEquals("Balance for u2 after O-201", 80, balance_u2);
//        assertEquals("Lifetime coins for u2", 80, users.get("u2").lifetimeCoins);
//        assertEquals("Tier for u2", Tier.PLUS, users.get("u2").tier);
//
//        System.out.println("✓ Earned: 80 coins");
//        System.out.println("✓ Balance: " + balance_u2);
//        System.out.println("✓ Lifetime Coins: " + users.get("u2").lifetimeCoins);
//        System.out.println("✓ Tier: " + users.get("u2").tier + "\n");
//
//        // ==================== CHECK FINAL BALANCE FOR USER 2 ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  STEP 12: Final checkBalance() - User u2");
//        System.out.println("└────────────────────────────────────────────────┘\n");
//
//        walletService.checkBalance();
//
//        assertEquals("User 2 final balance", 80, balance_u2);
//        System.out.println("✓ User u2 Final Balance: " + balance_u2 + " coins\n");
//
//        // ==================== SUMMARY ====================
//        System.out.println("┌────────────────────────────────────────────────┐");
//        System.out.println("  TEST SUMMARY");
//        System.out.println("└────────────────────────────────────────────────┘\n");
//
//        System.out.println("User u1 (REGULAR):");
//        System.out.println("  Final Balance: 50 coins");
//        System.out.println("  Lifetime Coins: 100 coins");
//        System.out.println("  Transactions: 6");
//        System.out.println("  Tier: REGULAR\n");
//
//        System.out.println("User u2 (PLUS):");
//        System.out.println("  Final Balance: 80 coins");
//        System.out.println("  Lifetime Coins: 80 coins");
//        System.out.println("  Transactions: 1");
//        System.out.println("  Tier: PLUS\n");
//
//        System.out.println("Key Verifications:");
//        System.out.println("  ✓ FIFO coin deduction verified");
//        System.out.println("  ✓ 30-day expiry logic verified");
//        System.out.println("  ✓ Tier-based calculations verified");
//        System.out.println("  ✓ Insufficient balance handling verified");
//        System.out.println("  ✓ Refund with fresh expiry verified");
//        System.out.println("  ✓ Transaction tracking verified");
//        System.out.println("  ✓ Multi-user isolation verified\n");
//    }
     ///////////////////////////////
    private static void testScenario() {

        System.out.println("════════════════ NEW TEST SCENARIO ════════════════\n");

        // DAY 1
        ctx.setCurrentDay(1);
        userService.login(users.get("u1"));
        walletService.earnCoins("O-1", 3000); // 50

        assertEquals("Day1 Balance", 50, users.get("u1").getWallet().getBalance(1));

        // DAY 10
        ctx.setCurrentDay(10);
        walletService.earnCoins("O-2", 5000); // 50

        assertEquals("Day10 Balance", 100, users.get("u1").getWallet().getBalance(10));

        // DAY 15
        ctx.setCurrentDay(15);
        walletService.spendCoins("O-3", 30);

        assertEquals("Day15 Balance", 70, users.get("u1").getWallet().getBalance(15));

        // DAY 32 → expiry should happen (20 coins)
        ctx.setCurrentDay(32);
        walletService.checkBalance();

        assertEquals("After expiry Day32", 50, users.get("u1").getWallet().getBalance(32));

        // DAY 33 → spend 40
        ctx.setCurrentDay(33);
        walletService.spendCoins("O-4", 40);

        assertEquals("Day33 Balance", 10, users.get("u1").getWallet().getBalance(33));

        // DAY 34 → refund
        ctx.setCurrentDay(34);
        walletService.cancelOrder("O-4");

        assertEquals("Day34 Balance after refund", 50, users.get("u1").getWallet().getBalance(34));

        // DAY 41 → expiry of remaining 10 from Day10 batch
        ctx.setCurrentDay(41);
        walletService.checkBalance();

        assertEquals("Day41 Balance after expiry", 40, users.get("u1").getWallet().getBalance(41));

        // DAY 50 → spend from refund batch
        ctx.setCurrentDay(50);
        walletService.spendCoins("O-5", 30);

        assertEquals("Day50 Balance", 10, users.get("u1").getWallet().getBalance(50));

        // FINAL TRANSACTION CHECK
        System.out.println("\n=== FINAL TRANSACTION HISTORY ===\n");
        walletService.history();

        System.out.println("\n════════════════ TEST COMPLETE ════════════════\n");
    }




    private static void assertEquals(String label, int expected, int actual) {
        if (expected != actual) {
            throw new AssertionError(label + " - Expected: " + expected + ", Got: " + actual);
        }
    }


}