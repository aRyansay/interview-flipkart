package com.interview.Enum;

public enum TransactionType {
    CREDIT, DEBIT, EXPIRY, REFUND
}
