package com.interview.Enum;

public enum Tier {
    REGULAR, PLUS
}
