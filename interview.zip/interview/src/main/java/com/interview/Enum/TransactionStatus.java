package com.interview.Enum;

public enum TransactionStatus {
    PENDING, IN_PROGRESS, COMPLETED, REJECTED, ROLLED_BACK
}
