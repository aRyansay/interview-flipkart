package com.interview.factory;

import com.interview.Enum.Tier;
import com.interview.strategy.PlusTierStrategy;
import com.interview.strategy.RegularTierStrategy;
import com.interview.strategy.TierStrategy;

public class TierFactory {
    public static TierStrategy getStrategy(Tier tier) {
        if (tier == Tier.PLUS) return new PlusTierStrategy();
        return new RegularTierStrategy();
    }
}