package com.interview.context;

import com.interview.entity.User;

public class SystemContext {
    private static SystemContext instance = new SystemContext();

    public User currentUser;
    public int currentDay;

    private SystemContext() {}

    public static SystemContext getInstance() {
        return instance;
    }

    public void setCurrentDay(int day) {
        this.currentDay = day;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }
}
