package com.interview;

import com.interview.Enum.Tier;
import com.interview.context.SystemContext;
import com.interview.entity.User;
import com.interview.service.UserService;
import com.interview.service.WalletService;

public class InterviewApplication {

	public static void main(String[] args) {
		System.out.println("╔════════════════════════════════════════════════════════════════╗");
		System.out.println("║     FLIPKART SUPERCOIN REWARD & WALLET SYSTEM - DEMO            ║");
		System.out.println("╚════════════════════════════════════════════════════════════════╝\n");

		runAllTests();
	}

	public static void runAllTests() {
		testMustHaveFeatures();
		testBonusFeatures();
	}

	public static void testMustHaveFeatures() {
		System.out.println("\n┌─────── MUST-HAVE FEATURES TESTS ───────┐\n");

		// Test 1: Login/Logout
		testLoginLogout();

		// Test 2: Earn SuperCoins - REGULAR & PLUS Tiers
		testEarnCoins();

		// Test 3: Expiry Rule
		testExpiryRule();

		// Test 4: Spend (FIFO)
		testSpendCoins();

		// Test 5: Cancel Order (Refund)
		testCancelOrder();

		// Test 6: View Balance, Tier, and History
		testViewOperations();
	}

	public static void testBonusFeatures() {
		System.out.println("\n┌─────── BONUS FEATURES TESTS ───────┐\n");

		// Test 7: Auto-Tier Upgrade
		testAutoTierUpgrade();

		// Test 8: Transaction Rollback
		testTransactionRollback();
	}

	private static void testLoginLogout() {
		System.out.println("TEST 1: LOGIN/LOGOUT");
		System.out.println("-".repeat(50));

		UserService userService = new UserService();
		User u1 = new User("user123", Tier.REGULAR);

		try {
			// Try to spend without login
			WalletService walletService = new WalletService();
			walletService.spendCoins("O-001", 10);
			System.out.println("❌ FAILED: Should have thrown UserNotLoggedInException");
		} catch (Exception e) {
			System.out.println("✓ Correctly caught exception: " + e.getMessage());
		}

		// Login
		userService.login(u1);
		System.out.println("✓ User logged in: " + u1.getUserId());

		// Logout
		userService.logout();
		System.out.println("✓ User logged out");

		try {
			WalletService walletService = new WalletService();
			walletService.spendCoins("O-002", 10);
			System.out.println("❌ FAILED: Should have thrown UserNotLoggedInException");
		} catch (Exception e) {
			System.out.println("✓ Correctly caught exception after logout: " + e.getMessage());
		}

		System.out.println();
	}

	private static void testEarnCoins() {
		System.out.println("TEST 2: EARN COINS (REGULAR & PLUS TIERS)");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		// Test REGULAR Tier
		User regularUser = new User("regularUser", Tier.REGULAR);
		userService.login(regularUser);
		ctx.setCurrentDay(1);

		System.out.println("REGULAR TIER: 2 coins per 100 Rs (max 50)");
		walletService.earnCoins("O-100", 1000);
		System.out.println("✓ Order O-100: 1000 Rs → Expected: 20 coins");

		walletService.earnCoins("O-101", 5000);
		System.out.println("✓ Order O-101: 5000 Rs → Expected: 50 coins (capped)");

		walletService.checkBalance();

		// Test PLUS Tier
		User plusUser = new User("plusUser", Tier.PLUS);
		userService.login(plusUser);
		ctx.setCurrentDay(5);

		System.out.println("PLUS TIER: 4 coins per 100 Rs (max 100)");
		walletService.earnCoins("O-200", 1000);
		System.out.println("✓ Order O-200: 1000 Rs → Expected: 40 coins");

		walletService.earnCoins("O-201", 5000);
		System.out.println("✓ Order O-201: 5000 Rs → Expected: 100 coins (capped)");

		walletService.checkBalance();

		System.out.println();
	}

	private static void testExpiryRule() {
		System.out.println("TEST 3: COIN EXPIRY RULE (30 DAYS)");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		User user = new User("expiryTestUser", Tier.REGULAR);
		userService.login(user);

		// Day 1: Earn 100 coins
		ctx.setCurrentDay(1);
		walletService.earnCoins("O-300", 5000);
		System.out.println("Day 1: Earned 50 coins");
		walletService.checkBalance();

		// Day 15: Coins still valid
		ctx.setCurrentDay(15);
		System.out.println("Day 15: Checking balance (coins valid until day 31)");
		walletService.checkBalance();

		// Day 31: Coins should expire (earned on day 1, expires on day 31)
		ctx.setCurrentDay(31);
		System.out.println("Day 31: Coins should be expired");
		walletService.checkBalance();

		System.out.println();
	}

	private static void testSpendCoins() {
		System.out.println("TEST 4: SPEND COINS (FIFO RULE)");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		User user = new User("fifoTestUser", Tier.REGULAR);
		userService.login(user);

		// Day 1: Earn 50 coins
		ctx.setCurrentDay(1);
		walletService.earnCoins("O-400", 5000);
		System.out.println("Day 1: Earned 50 coins");

		// Day 5: Earn 40 coins
		ctx.setCurrentDay(5);
		walletService.earnCoins("O-401", 2000);
		System.out.println("Day 5: Earned 40 coins");

		walletService.checkBalance();
		System.out.println("Total: 90 coins (50 from day 1, 40 from day 5)");

		// Day 10: Spend 70 coins - should use 50 from day 1, then 20 from day 5 (FIFO)
		ctx.setCurrentDay(10);
		System.out.println("\nDay 10: Spending 70 coins");
		walletService.spendCoins("O-402", 70);
		System.out.println("✓ Spent 70 coins (FIFO: 50 from batch1 + 20 from batch2)");

		walletService.checkBalance();
		System.out.println("Remaining: 20 coins (from day 5 batch)");

		// Try to spend more than available
		System.out.println("\nTrying to spend 50 coins (only 20 available)");
		try {
			walletService.spendCoins("O-403", 50);
			System.out.println("❌ FAILED: Should have thrown InsufficientBalanceException");
		} catch (Exception e) {
			System.out.println("✓ Correctly caught exception: " + e.getMessage());
		}

		walletService.checkBalance();

		System.out.println();
	}

	private static void testCancelOrder() {
		System.out.println("TEST 5: CANCEL ORDER (REFUND COINS)");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		User user = new User("cancelTestUser", Tier.REGULAR);
		userService.login(user);

		// Day 1: Earn 100 coins
		ctx.setCurrentDay(1);
		walletService.earnCoins("O-500", 5000);
		System.out.println("Day 1: Earned 50 coins");

		// Day 5: Spend 30 coins on order O-501
		ctx.setCurrentDay(5);
		walletService.spendCoins("O-501", 30);
		System.out.println("Day 5: Spent 30 coins on order O-501");
		walletService.checkBalance();
		System.out.println("Remaining: 20 coins\n");

		// Day 10: Cancel order O-501 (refund 30 coins)
		ctx.setCurrentDay(10);
		walletService.cancelOrder("O-501");
		System.out.println("Day 10: Cancelled order O-501");
		walletService.checkBalance();
		System.out.println("Note: Refunded coins have fresh 30-day validity (expire on day 40)\n");

		// Day 35: Original coins expired, but refunded coins still valid
		ctx.setCurrentDay(35);
		System.out.println("Day 35: Original coins expired, refunded coins still valid");
		walletService.checkBalance();

		// Day 40: All coins expired
		ctx.setCurrentDay(40);
		System.out.println("Day 40: Refunded coins also expired");
		walletService.checkBalance();

		System.out.println();
	}

	private static void testViewOperations() {
		System.out.println("TEST 6: VIEW OPERATIONS (BALANCE, TIER, HISTORY)");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		User user = new User("viewTestUser", Tier.REGULAR);
		userService.login(user);

		ctx.setCurrentDay(1);
		walletService.earnCoins("O-600", 1000);
		ctx.setCurrentDay(5);
		walletService.spendCoins("O-601", 10);

		System.out.println("✓ Current Balance and Tier:");
		walletService.checkBalance();

		System.out.println("✓ Transaction History:");
		walletService.history();

		System.out.println();
	}

	private static void testAutoTierUpgrade() {
		System.out.println("TEST 7: AUTO-TIER UPGRADE (300+ LIFETIME COINS)");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		User user = new User("upgradeTestUser", Tier.REGULAR);
		userService.login(user);

		ctx.setCurrentDay(1);

		// Earn coins to trigger upgrade
		System.out.println("Earning coins to reach 300+ lifetime coins threshold...\n");

		int[] amounts = {5000, 5000, 5000, 2500}; // Will give 50, 50, 50, 25 = 175 coins total (not enough)
		for (int i = 0; i < amounts.length; i++) {
			walletService.earnCoins("O-700-" + i, amounts[i]);
		}

		System.out.println("\nCurrent Status:");
		walletService.checkBalance();

		// Earn more to cross 300
		System.out.println("Earning more coins to cross 300 threshold...\n");

		for (int i = 0; i < 3; i++) {
			walletService.earnCoins("O-701-" + i, 5000);
		}

		System.out.println("\nFinal Status:");
		walletService.checkBalance();

		System.out.println();
	}

	private static void testTransactionRollback() {
		System.out.println("TEST 8: TRANSACTION ROLLBACK");
		System.out.println("-".repeat(50));

		SystemContext ctx = SystemContext.getInstance();
		UserService userService = new UserService();
		WalletService walletService = new WalletService();

		User user = new User("rollbackTestUser", Tier.REGULAR);
		userService.login(user);

		ctx.setCurrentDay(1);
		walletService.earnCoins("O-800", 5000);
		System.out.println("Day 1: Earned 50 coins");
		walletService.checkBalance();

		// Simulate a failed spend
		ctx.setCurrentDay(5);
		System.out.println("\nDay 5: Simulating failed spend of 40 coins");
		walletService.simulateFailedSpend("O-801", 40);

		System.out.println("\nAfter rollback:");
		walletService.checkBalance();
		System.out.println("✓ Coins restored successfully with original expiry dates");

		System.out.println("\nTransaction History:");
		walletService.history();

		System.out.println();
	}
}
