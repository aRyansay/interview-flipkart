package com.interview.service;

import com.interview.context.SystemContext;
import com.interview.entity.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserService {

    private Map<String, User> users = new HashMap<>();

    public void preloadUsers(List<User> userList) {
        for (User u : userList) {
            users.put(u.toString(), u);
        }
    }

    public void login(User user) {
        SystemContext.getInstance().setCurrentUser(user);
    }

    public void logout() {
        SystemContext.getInstance().setCurrentUser(null);
    }
}