package com.interview.service;

import com.interview.Enum.Tier;
import com.interview.Enum.TransactionStatus;
import com.interview.Enum.TransactionType;
import com.interview.context.SystemContext;
import com.interview.entity.CoinBatch;
import com.interview.entity.Transaction;
import com.interview.entity.User;
import com.interview.exception.InsufficientBalanceException;
import com.interview.exception.UserNotLoggedInException;
import com.interview.factory.TierFactory;
import com.interview.observer.ExpiryObserver;
import com.interview.strategy.TierStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WalletService {
    private List<ExpiryObserver> expiryObservers = new ArrayList<>();

    private void validateUserLoggedIn() {
        if (SystemContext.getInstance().currentUser == null) {
            throw new UserNotLoggedInException();
        }
    }

    private void handleExpiry(User user, int day) {
        int expired = user.getWallet().expireCoins(day);
        if (expired > 0) {
            // Notify all observers
            for (ExpiryObserver observer : expiryObservers) {
                observer.onCoinExpiry(user, expired, day);
            }
        }
    }

    public void registerExpiryObserver(ExpiryObserver observer) {
        expiryObservers.add(observer);
    }

    public void removeExpiryObserver(ExpiryObserver observer) {
        expiryObservers.remove(observer);
    }

    public void earnCoins(String orderId, int amount) {
        validateUserLoggedIn();
        
        SystemContext ctx = SystemContext.getInstance();
        User user = ctx.currentUser;

        handleExpiry(user, ctx.currentDay);

        TierStrategy strategy = TierFactory.getStrategy(user.getTier());
        int coins = strategy.calculateCoins(amount);

        user.getWallet().credit(coins, ctx.currentDay);
        user.incrementLifetimeCoins(coins);

        Transaction txn = new Transaction(UUID.randomUUID().toString(),
                TransactionType.CREDIT, coins, ctx.currentDay, orderId);

        txn.setStatus(TransactionStatus.COMPLETED);
        user.addTransaction(txn);

        // Auto upgrade
        if (user.getTier() == Tier.REGULAR && user.getLifetimeCoins() >= 300) {
            user.setTier(Tier.PLUS);
            System.out.println("[AUTO UPGRADE] User " + user.getUserId() + " upgraded to PLUS tier!");
        }
    }

    public void spendCoins(String orderId, int coins) {
        validateUserLoggedIn();
        
        SystemContext ctx = SystemContext.getInstance();
        User user = ctx.currentUser;

        handleExpiry(user, ctx.currentDay);

        Transaction txn = new Transaction(UUID.randomUUID().toString(),
                TransactionType.DEBIT, coins, ctx.currentDay, orderId);

        try {
            txn.setStatus(TransactionStatus.IN_PROGRESS);

            Map<CoinBatch, Integer> used = user.getWallet().debit(coins, ctx.currentDay);
            txn.setBatchBreakup(used);

            txn.setStatus(TransactionStatus.COMPLETED);
        } catch (InsufficientBalanceException e) {
            txn.setStatus(TransactionStatus.REJECTED);
            user.addTransaction(txn);
            throw e;
        } catch (Exception e) {
            txn.setStatus(TransactionStatus.REJECTED);
            user.addTransaction(txn);
            throw e;
        }

        user.addTransaction(txn);
    }

    public void simulateFailedSpend(String orderId, int coins) {
        validateUserLoggedIn();
        
        SystemContext ctx = SystemContext.getInstance();
        User user = ctx.currentUser;

        handleExpiry(user, ctx.currentDay);

        Transaction txn = new Transaction(UUID.randomUUID().toString(),
                TransactionType.DEBIT, coins, ctx.currentDay, orderId);

        try {
            txn.setStatus(TransactionStatus.IN_PROGRESS);

            Map<CoinBatch, Integer> used = user.getWallet().debit(coins, ctx.currentDay);
            txn.setBatchBreakup(used);

            // Simulate failure - rollback
            user.getWallet().restore(used);
            
            txn.setStatus(TransactionStatus.ROLLED_BACK);
            user.addTransaction(txn);
            
            System.out.println("[ROLLBACK] Transaction failed. Coins restored to wallet.");
        } catch (Exception e) {
            txn.setStatus(TransactionStatus.REJECTED);
            user.addTransaction(txn);
            throw e;
        }
    }

    public void cancelOrder(String orderId) {
        validateUserLoggedIn();
        
        SystemContext ctx = SystemContext.getInstance();
        User user = ctx.currentUser;

        handleExpiry(user, ctx.currentDay);

        for (Transaction txn : user.getTransactions()) {
            if (txn.getOrderId() != null && txn.getOrderId().equals(orderId) && txn.getType() == TransactionType.DEBIT
                    && txn.getStatus() == TransactionStatus.COMPLETED) {

                int coins = txn.getCoins();
                user.getWallet().credit(coins, ctx.currentDay);

                Transaction refund = new Transaction(UUID.randomUUID().toString(),
                        TransactionType.REFUND, coins, ctx.currentDay, orderId);

                refund.setStatus(TransactionStatus.COMPLETED);
                user.addTransaction(refund);
                System.out.println("[REFUND] " + coins + " coins refunded for order " + orderId);
                return;
            }
        }
        System.out.println("[CANCEL] No completed debit transaction found for order " + orderId);
    }

    public void checkBalance() {
        validateUserLoggedIn();
        
        SystemContext ctx = SystemContext.getInstance();
        User user = ctx.currentUser;

        handleExpiry(user, ctx.currentDay);

        int balance = user.getWallet().getBalance(ctx.currentDay);
        System.out.println("\n=== BALANCE CHECK ===");
        System.out.println("User: " + user.getUserId());
        System.out.println("Tier: " + user.getTier());
        System.out.println("Current Balance: " + balance + " coins");
        System.out.println("Lifetime Coins: " + user.getLifetimeCoins() + " coins");
        System.out.println("Current Day: " + ctx.currentDay);
        System.out.println("====================\n");
    }

    public void history() {
        validateUserLoggedIn();
        
        User user = SystemContext.getInstance().currentUser;
        System.out.println("\n=== TRANSACTION HISTORY ===");
        System.out.println("User: " + user.getUserId() + "\n");
        
        if (user.getTransactions().isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            for (Transaction t : user.getTransactions()) {
                System.out.println(t.toString());
            }
        }
        System.out.println("==========================\n");
    }
}